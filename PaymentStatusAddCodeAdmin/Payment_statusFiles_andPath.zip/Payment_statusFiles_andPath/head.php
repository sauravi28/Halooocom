<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="bootstrap/css/bootstrap12.min.css">
<link rel="stylesheet" href="bootstrap/css/bootstrap13.min.css">
<link rel="stylesheet" href="bootstrap/css/bootstrap14.min.css">
<link rel="stylesheet" href="bootstrap/css/bootstrap15.min.css">
<link rel="stylesheet" href="bootstrap/css/bootstrap16.min.css">
<link rel="stylesheet" href="bootstrap/css/bootstrap17.min.css">
<!-- Font Awesome -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
<!--<link rel="stylesheet" type="text/css" href="../css/fontawesome-all.min.css" /> 
<link rel="stylesheet" type="text/css" href="../css/fontawesome-all.css" /> 
<link rel="stylesheet" type="text/css" href="../css/fontawesome.css" /> 
<link rel="stylesheet" type="text/css" href="../css/fontawesome.min.css" /> -->

<!-- Ionicons -->
<link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
<!-- Theme style -->
<link rel="stylesheet" href="dist/css/AdminLTE.min.css">
<link rel="stylesheet" href="dist/css/AdminLTE12.min.css">
<link rel="stylesheet" href="dist/css/AdminLTE13.min.css">
<link rel="stylesheet" href="dist/css/AdminLTE14.min.css">
<link rel="stylesheet" href="dist/css/AdminLTE15.min.css">
<!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
<link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
<link rel="stylesheet" href="dist/css/skins/_all-skins1.min.css">
<!-- iCheck -->
<link rel="stylesheet" href="plugins/iCheck/flat/blue.css">
<!-- Morris chart -->
<link rel="stylesheet" href="plugins/morris/morris.css">
<!-- jvectormap -->
<link rel="stylesheet" href="plugins/jvectormap/jquery-jvectormap-1.2.2.css">
<!-- Date Picker -->
<link rel="stylesheet" href="plugins/datepicker/datepicker3.css">
<!-- Daterange picker -->
<link rel="stylesheet" href="plugins/daterangepicker/daterangepicker-bs3.css">
<!-- bootstrap wysihtml5 - text editor -->
<link rel="stylesheet" href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
<link rel="stylesheet" href="tooltip.css">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700" rel="stylesheet"> 
<!--<style style="text/css">
.hovertable tr{
	background-color: #fff;	
	}
	
.hovertable tr:nth-child(even) {background-color: red;}

    .hovertable tr:hover {
          background-color: #000;
    }
</style>-->
<style style="text/css">
 .tablehead {
  background-color: #a5d26b !important;
  height: 45px;
 }
 
 .bgcolor_004 {
  background-color: #a5d26b;
  padding: 8px;
  color: #fff;
 }
 
 .bgcolor_005 {
  /* background-color: #dbebec;*/
  color: #000;
  font-size: 15px;
  padding: 8px;
 }
 
 .addfooter {
  background-color: #f9f9f9;
 }
 
 .addfooteredit {
  background-color: transparent;
 }
 
 .tableheadsmall {
  background-color: #4db3b3 !important;
  color: #fff;
  font-weight: 600;
  height: 33px;
  font-size: 15px;
 }
 
 .tableheadsmalledit {
  background-color: #6b7979 !important;
  color: #fff;
  font-weight: 500;
  height: 28px;
  font-size: 15px;
 }
  .addfootersmall {
  background-color: #eaeaea;
  font-size: 14px;
  font-weight: 700;
 }
 
 .titleline {
  margin-top: 7px;
  width: 35%;
 }
 
 .bgcolor_004edit {
  background-color: #a5d26b;
  padding: 8px;
  color: #fff;
  border-bottom: 1px solid #d4e4e2;
 }
 
 .bgcolor_005edit {
  background: url(images/bg3.jpg);
  color: #000;
  font-size: 15px;
  padding: 8px;
 }
 
 .note_edit {
  background: #f06852;
  color: #fff;
 }
 
 .editsmall {
  background: #fff;
  height: 30px;
  color: #000;
 }
 
 .footersmallbox {
  width: 100%;
  float: right;
 }
 
 .footersmallbox1 {
  border: 5px solid #36457E;
  background-color: #a5d26b;
  color:#36457e;
 }
 .footersmallbox1 font{
  color: #36457e;
 }
 .tableheadsmalledit1 {
  background-color: #36457E;
  color: #fff;
  font-weight: 500;
  height: 28px;
  font-size: 14px;
 }
 /*.footersmallbox1 tr{
  color: #36457e;
 }*/
 table tr{
  color: #36457e;
 }
 
 .adminmain {
  border-bottom: 1px solid #f4f4f4;
  padding: 7px;
 }
 
 .form-control1 {
  border-color: #d2d6de;
  background-color: #fff;
  color: #202020;
  font-size: 15px;
  height: 30px;
  line-height: 1.42857;
  padding: 4px 12px;
  transition: border-color 0.15s ease-in-out 0s, box-shadow 0.15s ease-in-out 0s;
  border-radius: 0;
  box-shadow: none;
 }
 
 .content23 {
  margin-left: auto;
  margin-right: auto;
  min-height: 250px;
  padding: 3px;
 }
 
 .butnout {
  font-size: 40px;
  color: red;
  text-align: center;
  height: 42px;
  width: 41px;
  line-height: 18px;
  border-radius: 50%;
  background-color: #f3f3f3;
  display: block;
  margin: auto;
 }
 
 .mgg {
  background-image: url(./images/bg3.jpg);
  background-size: cover;
 }
 
    .blink {
        animation: blinker 0.6s linear infinite;
        color: #1c87c9;
        font-size: 30px;
        font-weight: bold;
        font-family: sans-serif;
      }
      @keyframes blinker {
        50% {
          opacity: 0;
        }
      }
</style>

<?php

$stmt_user="SELECT user_group from vicidial_users where user='$PHP_AUTH_USER' $LOGadmin_viewable_groupsSQL;";
//echo $stmt_user;die;
		$rslt_user=mysql_to_mysqli($stmt_user, $link);
		$row_user=mysqli_fetch_row($rslt_user);
		$usergroup =$row_user[0];

	
$stmt="SELECT end_date FROM vicidial_expiry_date where user_group ='$usergroup' and payment_status = 'Unpaid'";
	//echo $stmt;
	//die;
	$rslt=mysqli_query($link,$stmt);
	$row_rslt = mysqli_fetch_array($rslt);
	$sla_expiry = $row_rslt[0];
	
	
if($sla_expiry !=''){
	
$date_before = $sla_expiry; //date from database 
$str2 = date('Y-m-d', strtotime('-5 days', strtotime($date_before)));
//echo $str2;
//die;

$date1 = $str2;   
$date2 = $sla_expiry;

function returnDates($fromdate, $todate) {
    $fromdate = \DateTime::createFromFormat('Y-m-d', $fromdate);
    $todate = \DateTime::createFromFormat('Y-m-d', $todate);
    return new \DatePeriod(
        $fromdate,
        new \DateInterval('P1D'),
        $todate->modify('+1 day')
    );
}

$datePeriod = returnDates($date1, $date2);
$date_def = array();
foreach($datePeriod as $date) {
    array_push($date_def, $date->format('Y-m-d'));
}


$today = date('Y-m-d');

}

?>

<body bgcolor="white" marginheight="0" marginwidth="0" leftmargin="0" topmargin="0" class="skin-blue sidebar-mini">
 <div class="wrapper">
  <header class="main-header">
   <!-- Logo -->
   <a href="./admin.php" class="logo">
    <!-- mini logo for sidebar mini 50x50 pixels --><span class="logo-mini">
          <img src="logo1.png" style="width: 140px; height:70px;">
	  </span>
    <!-- logo for regular state and mobile devices --><span class="logo-lg">
		<img src="logo1.png" style="width: 155px; height: 50px;">
	  </span> </a>
	  <?php if($sla_expiry !='' && $sla_expiry != '0000-00-00' ){ ?>
	    <marquee bgcolor='#1A2B6D' font style='bold;position:absolute;z-index:1030;' scrolldealy: default(85);><font size='5' face='auto'><font color='#D8BFD8'><?php if($date_def[0] ==$today || $date_def[1] ==$today || $date_def[2] ==$today || $date_def[3] ==$today || $date_def[4] ==$today || $date_def[5] ==$today){ echo "Note: Please clear the due amount for uninterrupted service.. "; ?><a href="../paymentStatusFile.php"><span style="font-size: medium;text-decoration: underline;"><?php echo _QXZ("Add Payment Status");}?></span></marquee> <br>
	<?php } ?>  
   <!-- Header Navbar: style can be found in header.less -->
  <nav class="navbar navbar-static-top" role="navigation">
    <!-- Sidebar toggle button
          <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
          </a>--><span style="color:#fff; font-size:18px;font-weight:400;display: inline-block;padding: 20px 0;">&nbsp;&nbsp;<?php echo date("l F j, Y G:i:s A") ?></span>
          <span> <?php echo "<h2 class='text-center' style='color:#1B2C6E; font-size:25px;font-weight:400;display: inline-block;padding: 0px 0px 0px 201px;'><b>"._QXZ("ADMIN PANEL")."</b></h2>";?></span>
		  
	<?php if($sla_expiry !='' && $sla_expiry != '0000-00-00'){ ?>
	     <span style="color:#1A2B6D;font-size:20px;font-weight:600;margin-left: 516px;display: inline-block;position: absolute;top: 21px;"><?php if($date_def[0] ==$today || $date_def[1] ==$today || $date_def[2] ==$today || $date_def[3] ==$today || $date_def[4] ==$today || $date_def[5] ==$today){ echo "<a href='https://www.instamojo.com/@haloocom/' target='_blank' style='color:#1A2B6D;text-decoration: underline;'>Payment</a>";} ?></span>
	<?php } ?>  
		
    <div class="navbar-custom-menu">
     <ul class="nav navbar-nav">
      <!-- Messages: style can be found in dropdown.less-->
      <!--<li class="dropdown notifications-menu" style="margin-right: 460px;">
       <?php echo "<h2 class='text-center' style='color:#1B2C6E;font-size:25px;'><b>"._QXZ("ADMIN PANEL")."</b></h2>";?> </li>-->
      <!-- User Account: style can be found in dropdown.less -->
      <li class="dropdown user user-menu">
       <a href="#" class="dropdown-toggle" data-toggle="dropdown">
        <div class="butnout"> <i class="fa fa-power-off" aria-hidden="true"></i> </div> <span class="hidden-xs"><?php //echo $PHP_AUTH_USER ?></span> </a>
       <ul class="dropdown-menu">
        <!-- User image -->
        <li class="user-header"> <img src="dist/img/VoIPInnovationsIconTerm.png" class="img-circle" alt="User Image">
         <p>
          <?php
$stmt="SELECT user_id,user,pass,full_name,user_level,user_group,phone_login,phone_pass,delete_users,delete_user_groups,delete_lists,delete_campaigns,delete_ingroups,delete_remote_agents,load_leads,campaign_detail,ast_admin_access,ast_delete_phones,delete_scripts,modify_leads,hotkeys_active,change_agent_campaign,agent_choose_ingroups,closer_campaigns,scheduled_callbacks,agentonly_callbacks,agentcall_manual,vicidial_recording,vicidial_transfers,delete_filters,alter_agent_interface_options,closer_default_blended,delete_call_times,modify_call_times,modify_users,modify_campaigns,modify_lists,modify_scripts,modify_filters,modify_ingroups,modify_usergroups,modify_remoteagents,modify_servers,view_reports,vicidial_recording_override,alter_custdata_override,qc_enabled,qc_user_level,qc_pass,qc_finish,qc_commit,add_timeclock_log,modify_timeclock_log,delete_timeclock_log,alter_custphone_override,vdc_agent_api_access,modify_inbound_dids,delete_inbound_dids,active,alert_enabled,download_lists,agent_shift_enforcement_override,manager_shift_enforcement_override,shift_override_flag,export_reports,delete_from_dnc,email,user_code,territory,allow_alerts,agent_choose_territories,custom_one,custom_two,custom_three,custom_four,custom_five,voicemail_id,agent_call_log_view_override,callcard_admin,agent_choose_blended,realtime_block_user_info,custom_fields_modify,force_change_password,agent_lead_search_override,modify_shifts,modify_phones,modify_carriers,modify_labels,modify_statuses,modify_voicemail,modify_audiostore,modify_moh,modify_tts,preset_contact_search,modify_contacts,modify_same_user_level,admin_hide_lead_data,admin_hide_phone_data,agentcall_email,modify_email_accounts,failed_login_count,last_login_date,last_ip,alter_admin_interface_options,max_inbound_calls,modify_custom_dialplans,wrapup_seconds_override,modify_languages,selected_language,user_choose_language,ignore_group_on_search,api_list_restrict,api_allowed_functions,lead_filter_id,agentcall_chat,admin_cf_show_hidden,user_hide_realtime from vicidial_users where user='$PHP_AUTH_USER' $LOGadmin_viewable_groupsSQL;";
		$rslt=mysql_to_mysqli($stmt, $link);
		$row=mysqli_fetch_row($rslt);
		$user_group_bk =$row[5];
		$user_name = $row[1];
		$user_pass = $row[2];
?>
           <?php echo $PHP_AUTH_USER ?> -
            <?php echo $user_group_bk ?> <small><?php echo date("l F j, Y G:i:s A") ?></small> </p>
        </li>
        <!-- Menu Footer-->
        <li class="user-body">
         <div class="pull-left">
          <?php echo "<a href=\"$PHP_SELF?ADD=3&user=$PHP_AUTH_USER\" class='btn btn-default btn-flat'>";?>
           <?php echo _QXZ("Profile"); ?>
            </a>
         </div>
         <div class="pull-right">
          <a href="<?php echo $ADMIN ?>?force_logout=1" class="btn btn-default btn-flat">
           <?php echo _QXZ("Sign out"); ?>
          </a>
         </div>
         <!-- start Change Language-->
         <?php
if ($SSenable_languages == '1')
	{
	echo "<center><a href=\"$ADMIN?ADD=999989\">"._QXZ("Change language")."</a></center>";
	}
?>
          <!-- end Change Language-->
        </li>
       </ul>
      </li>
      <!-- Control Sidebar Toggle Button -->
      <!-- <li>
                <a href="#" data-toggle="control-sidebar"><i class="fa fa-gears"></i></a>
              </li>-->
      <li> &nbsp; </li>
     </ul>
    </div>
    <!-- start date-time border-->
    <div class="navbar-custom-menu head-time" style="min-height:18px; width: 290px; font-size:18px; color:#fff; ">
     <ul class="nav navbar-nav" style="margin-left: 10px;"> </ul>
    </div>
    <!-- end date-time border-->
   </nav>
   <!-- start date-time border
          
          <div class="navbar-custom-menu" style="background: #f06852; min-height:18px; width: 290px; font-size:16px; color:#fff; ">
            <ul class="nav navbar-nav" style="margin-left: 25px;">
            
              <li class="dropdown messages-menu">
               <small><?php //echo date("l F j, Y G:i:s A") ?></small>
              </li>
            </ul>
          </div>-->
   <!-- end date-time border-->
  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
   <!-- sidebar: style can be found in sidebar.less -->
   <section class="sidebar">
    <!-- Sidebar user panel -->
    <div class="user-panel">
     <div class="pull-left image"> <img src="dist/img/VoIPInnovationsIconTerm.png" class="img-circle" alt="User Image"> </div>
     <div class="pull-left info">
      <p>
       <?php echo $PHP_AUTH_USER ?>
      </p> <a href="#"><i class="fa fa-circle text-success"></i> <?php echo  _QXZ("Online");  ?></a> </div>
    </div>
    <!-- sidebar menu: : style can be found in sidebar.less -->
    <ul class="sidebar-menu">
     <li class="header">
      <?php echo  _QXZ("ADMINISTRATION");  ?>
     </li>
     <?php
	if ( ($reports_only_user < 1) and ($qc_only_user < 1) )
		{
	?>
      <!-- USERS NAVIGATION -->
      <li class="treeview">
       <a href="#"> <i class="fa fa-fw fa-users"></i> <span><?php echo  _QXZ("Users");  ?></span> <i class="fa fa-angle-left pull-right"></i> </a>
       <ul class="treeview-menu">
        <li><a href="<?php echo $ADMIN ?>?ADD=999998"><i class="fa fa-circle-o"></i><?php echo  _QXZ("Show Users");  ?></a></li>
        <li>
         <?php if ($add_copy_disabled < 1) { ?> <a href="<?php echo $ADMIN ?>?ADD=1"><i class="fa fa-circle-o"></i><?php echo  _QXZ("Add A New User");  ?></a></li>
        <li><a href="<?php echo $ADMIN ?>?ADD=1A"><i class="fa fa-circle-o"></i><?php echo  _QXZ("Copy User");  ?></a></li>
        <li>
         <?php } ?> <a href="<?php echo $ADMIN ?>?ADD=550"><i class="fa fa-circle-o"></i><?php echo  _QXZ("Search For A User");  ?></a></li>
        <li><a href="./user_stats.php?user=<?php echo $user ?>"><i class="fa fa-circle-o"></i><?php echo  _QXZ("User Stats");  ?></a></li>
        <li><a href="./user_status.php?user=<?php echo $user ?>"><i class="fa fa-circle-o"></i><?php echo  _QXZ("User Status");  ?></a></li>
        <li><a href="./AST_agent_time_sheet.php?agent=<?php echo $user ?>"><i class="fa fa-circle-o"></i><?php echo  _QXZ("Time Sheet");  ?></a></li>
		
        <?php
	if ( ($SSuser_territories_active > 0) or ($user_territories_active > 0) )
		{ ?>
         <li><a href="./user_territories.php?agent=<?php echo $user ?>"><i class="fa fa-circle-o"></i><?php echo  _QXZ("User Territories");  ?></a></li>
         <?php } 
	  
	?>
       </ul>
      </li>
      <!-- CAMPAIGNS NAVIGATION -->
      <li class="treeview">
       <a href="#"> <i class="fa fa-share"></i> <span><?php echo  _QXZ("Campaigns");  ?></span> <i class="fa fa-angle-left pull-right"></i> </a>
       <?php
	/*if (strlen($campaigns_hh) > 1) 
		{*/ 
		if ($sh=='basic') {$sh='list';}
		if ($sh=='detail') {$sh='list';}
		if ($sh=='dialstat') {$sh='list';}

		if ($sh=='list') {$list_sh="bgcolor=\"$subcamp_color\""; $list_fc="$subcamp_font";}
			else {$list_sh=''; $list_fc='BLACK';}
		if ($sh=='status') {$status_sh="bgcolor=\"$subcamp_color\""; $status_fc="$subcamp_font";}
			else {$status_sh=''; $status_fc='BLACK';}
		if ($sh=='hotkey') {$hotkey_sh="bgcolor=\"$subcamp_color\""; $hotkey_fc="$subcamp_font";}
			else {$hotkey_sh=''; $hotkey_fc='BLACK';}
		if ($sh=='recycle') {$recycle_sh="bgcolor=\"$subcamp_color\""; $recycle_fc="$subcamp_font";}
			else {$recycle_sh=''; $recycle_fc='BLACK';}
		if ($sh=='autoalt') {$autoalt_sh="bgcolor=\"$subcamp_color\""; $autoalt_fc="$subcamp_font";}
			else {$autoalt_sh=''; $autoalt_fc='BLACK';}
		if ($sh=='pause') {$pause_sh="bgcolor=\"$subcamp_color\""; $pause_fc="$subcamp_font";}
			else {$pause_sh=''; $pause_fc='BLACK';}
		if ($sh=='listmix') {$listmix_sh="bgcolor=\"$subcamp_color\""; $listmix_fc="$subcamp_font";}
			else {$listmix_sh=''; $listmix_fc='BLACK';}
		if ($sh=='preset') {$preset_sh="bgcolor=\"$subcamp_color\""; $preset_fc="$subcamp_font";}
			else {$preset_sh=''; $preset_fc='BLACK';}
		if ($sh=='accid') {$accid_sh="bgcolor=\"$subcamp_color\""; $accid_fc="$subcamp_font";}
			else {$accid_sh=''; $accid_fc='BLACK';}

		?>
        <ul class="treeview-menu">
         <li> <a href="<?php echo $ADMIN ?>?ADD=10"><i class="fa fa-circle-o"></i><?php echo  _QXZ("Campaigns Main");  ?></a>
          <!-- <ul class="treeview-menu">
                    <li><a href="#"><i class="fa fa-circle-o"></i> Level Two</a></li>
                   </ul>-->
         </li>
         <li><a href="<?php echo $ADMIN ?>?ADD=32"><i class="fa fa-circle-o"></i><?php echo  _QXZ("Statuses");  ?></a></li>
         <li><a href="<?php echo $ADMIN ?>?ADD=33"><i class="fa fa-circle-o"></i><?php echo  _QXZ("HotKeys");  ?></a>
          <?php
		if ($SSoutbound_autodial_active > 0)
			{
			?>
         </li>
         <li><a href="<?php echo $ADMIN ?>?ADD=35"><i class="fa fa-circle-o"></i><?php echo  _QXZ("Lead Recycle");  ?></a></li>
         <li><a href="<?php echo $ADMIN ?>?ADD=36"><i class="fa fa-circle-o"></i><?php echo  _QXZ("Auto-Alt Dial");  ?></a></li>
         <li><a href="<?php echo $ADMIN ?>?ADD=39"><i class="fa fa-circle-o"></i><?php echo  _QXZ("List Mix");  ?></a>
          <?php
			}
		?>
         </li>
         <li><a href="<?php echo $ADMIN ?>?ADD=37"><i class="fa fa-circle-o"></i><?php echo  _QXZ("Pause Codes");  ?></a></li>
         <li><a href="<?php echo $ADMIN ?>?ADD=301"><i class="fa fa-circle-o"></i><?php echo  _QXZ("Presets");  ?></a>
          <?php
		if ($SScampaign_cid_areacodes_enabled > 0)
			{
			?>
         </li>
         <li><a href="<?php echo $ADMIN ?>?ADD=302"><i class="fa fa-circle-o"></i><?php echo  _QXZ("AC-CID");  ?></a>
          <?php
			}
		 
	?>
         </li>
        </ul>
      </li>
      <!-- LISTS NAVIGATION -->
      <?php
		if ($SSoutbound_autodial_active > 0)
		{
		?>
       <li class="treeview"><a href="#"><i class="fa fa-files-o"></i> <span><?php echo  _QXZ("Lists");  ?></span><i class="fa fa-angle-left pull-right"></i>
              </a>
        <?php
	
			 
			if ($LOGdelete_from_dnc > 0) {$DNClink = "Add-Delete DNC Number";}
			else {$DNClink = "Add DNC Number";}
			?>
         <ul class="treeview-menu">
          <li><a href="<?php echo $ADMIN ?>?ADD=100"><i class="fa fa-circle-o"></i><?php echo  _QXZ("Show Lists");  ?></a></li>
          <li>
           <?php if ($add_copy_disabled < 1) { ?><a href="<?php echo $ADMIN ?>?ADD=111"><i class="fa fa-circle-o"></i><?php echo  _QXZ("Add A New List");  ?></a></li>
          <li>
           <?php } ?><a href="admin_search_lead.php"><i class="fa fa-circle-o"></i><?php echo  _QXZ("Search For A Lead");  ?></a></li>
          <li><a href="admin_modify_lead.php"><i class="fa fa-circle-o"></i><?php echo  _QXZ("Add A New Lead");  ?></a></li>
          <li><a href="<?php echo $ADMIN ?>?ADD=121"><i class="fa fa-circle-o"></i><?php echo _QXZ("$DNClink");  ?></a></li>
          <li><a href="./admin_listloader_fourth_gen.php"><i class="fa fa-circle-o"></i><?php echo _QXZ("Load New Leads");  ?></a>
           <?php
			if ($SScustom_fields_enabled > 0)
				{
				$admin_lists_custom = 'admin_lists_custom.php';
				if (preg_match("/cf_encrypt/",$SSactive_modules))
					{$admin_lists_custom = 'admin_lists_custom_encrypt.php';}
				?>
          </li>
          <li><a href="./<?php echo $admin_lists_custom ?>"><i class="fa fa-circle-o"></i><?php echo _QXZ("List Custom Fields");  ?></a></li>
          <li><a href="./<?php echo $admin_lists_custom ?>?action=COPY_FIELDS_FORM"><i class="fa fa-circle-o"></i><?php echo _QXZ("Copy Custom Fields"); ?></a> </li>
          <?php
			}
		}

	if (($SSqc_features_active=='1') && ($qc_auth=='1')) 
		{ ?>
           <li><a href="<?php echo $ADMIN ?>?ADD=100000000000000"><i class="fa fa-circle-o"></i><?php echo _QXZ("Quality Control"); ?></a></li>
           <?php
	if (strlen($qc_hh) > 1) 
			{
		?>
            <li><a href="<?php echo $ADMIN ?>?ADD=100000000000000"><i class="fa fa-circle-o"></i><?php echo _QXZ("Show QC Campaigns"); ?></a></li>
            <li><a href="<?php echo $ADMIN ?>?ADD=100000000000000"><i class="fa fa-circle-o"></i><?php echo _QXZ("Enter QC Queue"); ?></a></li>
            <li><a href="<?php echo $ADMIN ?>?ADD=341111111111111"><i class="fa fa-circle-o"></i><?php echo _QXZ("Modify QC Codes"); ?></a></li>
            <?php }
		}
	?>
         </ul>
       </li>
       <!-- SCRIPTS NAVIGATION -->
       <li class="treeview">
        <a href="#"> <i class="fa fa-edit"></i> <span><?php echo _QXZ("Scripts"); ?></span> <i class="fa fa-angle-left pull-right"></i> </a>
        <ul class="treeview-menu">
         <li><a href="<?php echo $ADMIN ?>?ADD=1000000"><i class="fa fa-circle-o"></i><?php echo _QXZ("Show Scripts"); ?></a></li>
         <li>
          <?php if ($add_copy_disabled < 1) { ?><a href="<?php echo $ADMIN ?>?ADD=1111111"><i class="fa fa-circle-o"></i><?php echo _QXZ("Add A New Script"); ?></a>
           <?php } ?>
         </li>
         <li><a href="<?php echo $ADMIN ?>?ADD=75111111"><i class="fa fa-circle-o"></i><?php echo _QXZ("Directory"); ?></a></li>
        </ul>
       </li>
       <!-- FILTERS NAVIGATION -->
       <!-- INGROUPS NAVIGATION -->
       <li class="treeview">
              <a href="#">
                <i class="fa fa-folder"></i> <span><?php echo _QXZ("Inbound"); ?></span> <i class="fa fa-angle-left pull-right"></i>
              </a>
		<?php
	
		if ($LOGdelete_from_dnc > 0) {$FPGlink = "Add-Delete FPG Number";}
		else {$FPGlink = "Add FPG Number";}
		?>
              <ul class="treeview-menu">
                <li><a href="<?php echo $ADMIN ?>?ADD=1000"><i class="fa fa-circle-o"></i><?php echo _QXZ("Show In-Groups"); ?></a></li>
                <li><?php if ($add_copy_disabled < 1) { ?><a href="<?php echo $ADMIN ?>?ADD=1111"><i class="fa fa-circle-o"></i><?php echo _QXZ("Add A New In-Group"); ?></a></li>
		<li><a href="<?php echo $ADMIN ?>?ADD=1211"><i class="fa fa-circle-o"></i><?php echo _QXZ("Copy In-Group"); ?></a></li>
		<?php } ?>
		<HR>
		<?php
		if ($SSemail_enabled>0) 
			{
		?>

		<li><a href="<?php echo $ADMIN ?>?ADD=1800"><i class="fa fa-circle-o"></i><?php echo _QXZ("Show Email Groups"); ?></a></li>
		<li><?php if ($add_copy_disabled < 1) { ?><a href="<?php echo $ADMIN ?>?ADD=1811"><i class="fa fa-circle-o"></i><?php echo _QXZ("Add New Email Group"); ?></a></li>
		<li><a href="<?php echo $ADMIN ?>?ADD=1911"><i class="fa fa-circle-o"></i><?php echo _QXZ("Copy Email Group"); ?></a></li>
		<?php } ?>
		<HR>
		<?php
			}
		?>
		<?php
		if ($SSchat_enabled>0) 
			{
		?>
		
		<li><a href="<?php echo $ADMIN ?>?ADD=1900"><i class="fa fa-circle-o"></i><?php echo _QXZ("Show Chat Groups"); ?></a></li>
		<li><?php if ($add_copy_disabled < 1) { ?><a href="<?php echo $ADMIN ?>?ADD=18111"><i class="fa fa-circle-o"></i><?php echo _QXZ("Add New Chat Group"); ?></a></li>
		<li><a href="<?php echo $ADMIN ?>?ADD=19111"><i class="fa fa-circle-o"></i><?php echo _QXZ("Copy Chat Group"); ?></a>
		<?php } ?>
		<HR>
		<?php
			}
		?>
		</li>

		<li><a href="<?php echo $ADMIN ?>?ADD=1300"><i class="fa fa-circle-o"></i><?php echo _QXZ("Show DIDs"); ?></a></li>
		<li><?php if ($add_copy_disabled < 1) { ?><a href="<?php echo $ADMIN ?>?ADD=1311"><i class="fa fa-circle-o"></i><?php echo _QXZ("Add A New DID"); ?></a></li>
		<li><a href="<?php echo $ADMIN ?>?ADD=1411"><i class="fa fa-circle-o"></i><?php echo _QXZ("Copy DID"); ?></a>
		<?php
			}
		if ($SSdid_ra_extensions_enabled > 0)
			{
			?>
		</li>
		<li><a href="<?php echo $ADMIN ?>?ADD=1320"><i class="fa fa-circle-o"></i><?php echo _QXZ("RA Extensions"); ?></a>
		<?php
			}
		?>
		<HR>
		</li>
		
		<li><a href="<?php echo $ADMIN ?>?ADD=1500"><i class="fa fa-circle-o"></i><?php echo _QXZ("Show Call Menus"); ?></a></li>
		<li><?php if ($add_copy_disabled < 1) { ?><a href="<?php echo $ADMIN ?>?ADD=1511"><i class="fa fa-circle-o"></i><?php echo _QXZ("Add A New Call Menu"); ?></a></li>
		<li><a href="<?php echo $ADMIN ?>?ADD=1611"><i class="fa fa-circle-o"></i><?php echo _QXZ("Copy Call Menu"); ?></a>
		<?php } ?>
<!--		<HR>-->
		</li>

		<!--<li><a href="<?php echo $ADMIN ?>?ADD=1700"><i class="fa fa-circle-o"></i><?php echo _QXZ("Filter Phone Groups"); ?></a></li>
		<li><?php if ($add_copy_disabled < 1) { ?><a href="<?php echo $ADMIN ?>?ADD=1711"><i class="fa fa-circle-o"></i><?php echo _QXZ("Add Filter Phone Group"); ?></a></li>
		<li><?php } ?><a href="<?php echo $ADMIN ?>?ADD=171"><i class="fa fa-circle-o"></i><?php echo _QXZ("$FPGlink"); ?></a></li>-->
				
		</ul>
            </li>
       <!-- USERGROUPS NAVIGATION -->
       <!--<li class="treeview">
              <a href="#">
                <i class="fa fa-book"></i> <span><?php echo _QXZ("User Groups"); ?></span> <i class="fa fa-angle-left pull-right"></i>
              </a>
		
              <ul class="treeview-menu">
                <li><a href="<?php echo $ADMIN ?>?ADD=100000"><i class="fa fa-circle-o"></i><?php echo _QXZ("Show User Groups"); ?></a></li>
                <li><?php if ($add_copy_disabled < 1) { ?><a href="<?php echo $ADMIN ?>?ADD=111111"><i class="fa fa-circle-o"></i><?php echo _QXZ("Add A New User Group"); ?></a></li>
		<li><?php } ?><a href="group_hourly_stats.php"><i class="fa fa-circle-o"></i><?php echo _QXZ("Group Hourly Report"); ?></a></li>
		<li><a href="user_group_bulk_change.php"><i class="fa fa-circle-o"></i><?php echo _QXZ("Bulk Group Change"); ?></a></li>
		
              </ul>
            </li>-->
       <!-- REMOTEAGENTS NAVIGATION 

		 <li class="treeview">
              <a href="#">
                <i class="fa fa-th"></i> <span><?php echo _QXZ("Remote Agents"); ?></span> <i class="fa fa-angle-left pull-right"></i>
              </a>
		
              <ul class="treeview-menu">
                <li><a href="<?php echo $ADMIN ?>?ADD=10000"><i class="fa fa-circle-o"></i><?php echo _QXZ("Show Remote Agents"); ?></a></li>
                <li><?php if ($add_copy_disabled < 1) { ?><a href="<?php echo $ADMIN ?>?ADD=11111"><i class="fa fa-circle-o"></i><?php echo _QXZ("Add New Remote Agents"); ?></a></li>
		<li><?php } ?><a href="<?php echo $ADMIN ?>?ADD=12000"><i class="fa fa-circle-o"></i><?php echo _QXZ("Show Extension Groups"); ?></a></li>
		<li><?php if ($add_copy_disabled < 1) { ?><a href="<?php echo $ADMIN ?>?ADD=12111"><i class="fa fa-circle-o"></i><?php echo _QXZ("Add Extension Group"); ?></a><?php } ?></li>
		
              </ul>
            </li>-->
       <!-- ADMIN NAVIGATION -->
       <li class="treeview">
        <a href="<?php echo $ADMIN ?>?ADD=0A"> <i class="fa fa-laptop"></i> <span><?php echo _QXZ("Admin"); ?></span> <i class="fa fa-angle-left pull-right"></i> </a>
        <?php
	if (strlen($admin_hh) > 1) 
		{
		if ($sh=='times') {$times_sh="bgcolor=\"$times_color\""; $times_fc="$times_font";}
			else {$times_sh=''; $times_fc='BLACK';}
		if ($sh=='shifts') {$shifts_sh="bgcolor=\"$shifts_color\""; $shifts_fc="$shifts_font";}
			else {$shifts_sh=''; $shifts_fc='BLACK';}
		if ($sh=='templates') {$templates_sh="bgcolor=\"$templates_color\""; $templates_fc="$templates_font";}
			else {$templates_sh=''; $templates_fc='BLACK';}
		if ($sh=='carriers') {$carriers_sh="bgcolor=\"$carriers_color\""; $carriers_fc="$carriers_font";}
			else {$carriers_sh=''; $carriers_fc='BLACK';}
		if ($sh=='phones') {$phones_sh="bgcolor=\"$server_color\""; $phones_fc="$phones_font";}
			else {$phones_sh=''; $phones_fc='BLACK';}
		if ($sh=='server') {$server_sh="bgcolor=\"$server_color\""; $server_fc="$server_font";}
			else {$server_sh=''; $server_fc='BLACK';}
		if ($sh=='conference') {$conference_sh="bgcolor=\"$server_color\""; $conference_fc="$server_font";}
			else {$conference_sh=''; $conference_fc='BLACK';}
		if ($sh=='settings') {$settings_sh="bgcolor=\"$settings_color\""; $settings_fc="$settings_font";}
			else {$settings_sh=''; $settings_fc='BLACK';}
		if ($sh=='label') {$label_sh="bgcolor=\"$label_color\""; $label_fc="$label_font";}
			else {$label_sh=''; $label_fc='BLACK';}
		if ($sh=='status') {$status_sh="bgcolor=\"$status_color\""; $status_fc="$status_font";}
			else {$status_sh=''; $status_fc='BLACK';}
		if ($sh=='audio') {$audio_sh="bgcolor=\"$audio_color\""; $audio_fc="$audio_font";}
			else {$audio_sh=''; $audio_fc='BLACK';}
		if ($sh=='moh') {$moh_sh="bgcolor=\"$moh_color\""; $moh_fc="$moh_font";}
			else {$moh_sh=''; $moh_fc='BLACK';}
		if ($sh=='languages') {$languages_sh="bgcolor=\"$languages_color\""; $languages_fc="$languages_font";}
			else {$languages_sh=''; $languages_fc='BLACK';}
		if ( preg_match("/avatar/",$SSactive_modules) )
			{
			if ($sh=='avatar') {$avatar_sh="bgcolor=\"$avatar_color\""; $avatar_fc="$avatar_font";}
				else {$avatar_sh=''; $avatar_fc='BLACK';}
			}
		if ($sh=='vm') {$vm_sh="bgcolor=\"$vm_color\""; $vm_fc="$vm_font";}
			else {$vm_sh=''; $vm_fc='BLACK';}
		if ($sh=='tts') {$tts_sh="bgcolor=\"$tts_color\""; $tts_fc="$tts_font";}
			else {$tts_sh=''; $tts_fc='BLACK';}
		if ($sh=='cc') {$cc_sh="bgcolor=\"$cc_color\""; $cc_fc="$cc_font";}
			else {$cc_sh=''; $cc_fc='BLACK';}
		if ($sh=='cts') {$cts_sh="bgcolor=\"$cts_color\""; $cts_fc="$cc_font";}
			else {$cts_sh=''; $cts_fc='BLACK';}
		if ($sh=='sc') {$sc_sh="bgcolor=\"$sc_color\""; $sc_fc="$cc_font";}
			else {$sc_sh=''; $sc_fc='BLACK';}
		if ($sh=='sg') {$sg_sh="bgcolor=\"$sg_color\""; $sg_fc="$cc_font";}
			else {$sg_sh=''; $sg_fc='BLACK';}
		if ($sh=='emails') {$emails_sh="bgcolor=\"$subcamp_color\""; $emails_fc="$subcamp_font";}
			else {$emails_sh=''; $emails_fc='BLACK';}


		?>
         <ul class="treeview-menu">
          <li <?php echo $times_sh ?>><a href="<?php echo $ADMIN ?>?ADD=100000000"><i class="fa fa-circle-o"></i> <?php echo _QXZ("Call Times"); ?></a></li>
          <li <?php echo $shifts_sh ?>><a href="<?php echo $ADMIN ?>?ADD=130000000"><i class="fa fa-circle-o"></i> <?php echo _QXZ("Shifts"); ?></a></li>
          <li <?php echo $phones_sh ?>><a href="<?php echo $ADMIN ?>?ADD=10000000000"><i class="fa fa-circle-o"></i> <?php echo _QXZ("Phones"); ?></a></li>
          <li <?php echo $templates_sh ?>><a href="<?php echo $ADMIN ?>?ADD=130000000000"><i class="fa fa-circle-o"></i><?php echo _QXZ("Templates"); ?></a></li>
          <li <?php echo $carriers_sh ?>><a href="<?php echo $ADMIN ?>?ADD=140000000000"><i class="fa fa-circle-o"></i><?php echo _QXZ("Carriers"); ?></a></li>
          <li <?php echo $server_sh ?>><a href="<?php echo $ADMIN ?>?ADD=100000000000"><i class="fa fa-circle-o"></i><?php echo _QXZ("Servers"); ?></a></li>
          <li <?php echo $conference_sh ?>><a href="<?php echo $ADMIN ?>?ADD=1000000000000"><i class="fa fa-circle-o"></i><?php echo _QXZ("Conferences"); ?></a></li>
          <li <?php echo $settings_sh ?>><a href="<?php echo $ADMIN ?>?ADD=311111111111111"><i class="fa fa-circle-o"></i><?php echo _QXZ("System Settings"); ?></a></li>
          <li <?php echo $label_sh ?>><a href="<?php echo $ADMIN ?>?ADD=180000000000"><i class="fa fa-circle-o"></i> <?php echo _QXZ("Screen Labels"); ?></a></li>
          <li <?php echo $status_sh ?>><a href="<?php echo $ADMIN ?>?ADD=321111111111111"><i class="fa fa-circle-o"></i><?php echo _QXZ("System Statuses"); ?></a></li>
          <li <?php echo $sg_sh ?>><a href="<?php echo $ADMIN ?>?ADD=193000000000"><i class="fa fa-circle-o"></i><?php echo _QXZ("Status Groups"); ?></a></li>
          <li <?php echo $vm_sh ?>><a href="<?php echo $ADMIN ?>?ADD=170000000000"><i class="fa fa-circle-o"></i> Voicemail</a></li>
          <?php
		if ($SSemail_enabled > 0)
			{ ?>
           <li <?php echo $emails_sh ?>><a href="admin_email_accounts.php"><i class="fa fa-circle-o"></i><?php echo _QXZ("Email Accounts"); ?></a></li>
           <?php }
		if ( ($sounds_central_control_active > 0) or ($SSsounds_central_control_active > 0) )
			{ ?>
            <li <?php echo $audio_sh ?>><a href="audio_store.php"><i class="fa fa-circle-o"></i><?php echo _QXZ("Audio Store"); ?></a></li>
            <li <?php echo $moh_sh ?>><a href="<?php echo $ADMIN ?>?ADD=160000000000"><i class="fa fa-circle-o"></i> <?php echo _QXZ("Music On Hold"); ?></a></li>
            <?php
		if ($SSenable_languages > 0)
			{ ?>
             <li <?php echo $languages_sh ?>><a href="admin_languages.php?ADD=163000000000"><i class="fa fa-circle-o"></i><?php echo _QXZ("Languages"); ?></a></li>
             <?php }
			if (preg_match("/avatar/",$SSactive_modules) )
				{
			?>
              <li <?php echo $avatar_sh ?>><a href="admin_avatar.php?ADD=162000000000"><i class="fa fa-circle-o"></i> <?php echo _QXZ("Audio Avatars"); ?></a></li>
              <?php 
				}
			}
		if ($SSenable_tts_integration > 0)
			{ ?>
               <li <?php echo $tts_sh ?>><a href="<?php echo $ADMIN ?>?ADD=150000000000"><i class="fa fa-circle-o"></i> <?php echo _QXZ("Text To Speech"); ?></a></li>
               <?php }
		if ($SScallcard_enabled > 0)
			{ ?>
                <li <?php echo $cc_sh ?>><a href="callcard_admin.php"><i class="fa fa-circle-o"></i><?php echo _QXZ("CallCard Admin"); ?></a></li>
                <?php }
		if ($SScontacts_enabled > 0)
			{ ?>
                 <li <?php echo $cts_sh ?>><a href="<?php echo $ADMIN ?>?ADD=190000000000"><i class="fa fa-circle-o"></i><?php echo _QXZ("Contacts"); ?></a></li>
                 <?php }
		?>
                  <li <?php echo $sc_sh ?>><a href="<?php echo $ADMIN ?>?ADD=192000000000"><i class="fa fa-circle-o"></i> <?php echo _QXZ("Settings Containers"); ?></a></li>
         </ul>
         <?php
			}
		?>
          <!-- REPORTS NAVIGATION -->
          <li>
           <a href="<?php echo $ADMIN ?>?ADD=999999"> <i class="fa fa-pie-chart"></i> <span><?php echo _QXZ("Reports");?></span> </a>
          </li>
          <!-- miscellaneous -->
          <li class="treeview">
           <a href="#"> <i class="fa fa-fw fa-users"></i> <span><?php echo  _QXZ("Miscellaneous");  ?></span> <i class="fa fa-angle-left pull-right"></i> </a>
           <ul class="treeview-menu">
            <?php
			if ($SSoutbound_autodial_active > 0)
				{
				?>
             <li><a href="<?php echo $ADMIN ?>?ADD=10000000"><i class="fa fa-circle-o"></i><?php echo _QXZ("Show Filters"); ?></a></li>
             <li>
              <?php if ($add_copy_disabled < 1) { ?><a href="<?php echo $ADMIN ?>?ADD=11111111"><i class="fa fa-circle-o"></i><?php echo _QXZ("Add A New Filter"); ?></a>
               <?php } ?>
             </li>
             <?php 
					}
				?>
              <li><a href="<?php echo $ADMIN ?>?ADD=100000"><i class="fa fa-circle-o"></i><?php echo _QXZ("Show User Groups"); ?></a></li>
              <li>
               <?php if ($add_copy_disabled < 1) { ?><a href="<?php echo $ADMIN ?>?ADD=111111"><i class="fa fa-circle-o"></i><?php echo _QXZ("Add A New User Group"); ?></a></li>
              <li>
               <?php } ?><a href="group_hourly_stats.php"><i class="fa fa-circle-o"></i><?php echo _QXZ("Group Hourly Report"); ?></a></li>
              <li><a href="user_group_bulk_change.php"><i class="fa fa-circle-o"></i><?php echo _QXZ("Bulk Group Change"); ?></a></li>
              <li><a href="<?php echo $ADMIN ?>?ADD=10000"><i class="fa fa-circle-o"></i><?php echo _QXZ("Show Remote Agents"); ?></a></li>
              <li>
               <?php if ($add_copy_disabled < 1) { ?><a href="<?php echo $ADMIN ?>?ADD=11111"><i class="fa fa-circle-o"></i><?php echo _QXZ("Add New Remote Agents"); ?></a></li>
              <li>
               <?php } ?><a href="<?php echo $ADMIN ?>?ADD=12000"><i class="fa fa-circle-o"></i><?php echo _QXZ("Show Extension Groups"); ?></a></li>
              <li>
               <?php if ($add_copy_disabled < 1) { ?><a href="<?php echo $ADMIN ?>?ADD=12111"><i class="fa fa-circle-o"></i><?php echo _QXZ("Add Extension Group"); ?></a>
                <?php } ?>
              </li>
           </ul>
          </li>
          <!--Ent  Mislenous -->
		  
		  <!-- EXPIRY DATE NAVIGATION -->
         
           <?php //if($user_name == 'sauravi') { ?> <li><a href="<?php echo $ADMIN ?>?ADD=2B"> <i class="fa fa-calendar"></i> <span><?php echo _QXZ("Add Expiry Date");?></span> </a> </li><?php// } ?>
         
		   <!--end EXPIRY DATE NAVIGATION -->  
		   
		   <li><a href="<?php echo $ADMIN ?>?ADD=2BB"> <i class="fa fa-file-text"></i> <span><?php echo _QXZ("Add Banner");?></span> </a> </li>
		   <li><a href="../paymentStatusFile.php"> <i class="fa fa-money"></i> <span><?php echo _QXZ("Add Payment Status");?></span> </a> </li>
		  <li><a href="update_comments.php"> <i class="fa fa-edit"></i> <span><?php echo _QXZ("Edit Comments");?></span> </a> </li>
		  
          <?php
		}
	else
		{
		if ($reports_only_user > 0)
			{
			?>
           <!-- REPORTS NAVIGATION -->
           <li>
            <a href="<?php echo $ADMIN ?>?ADD=999999"> <i class="fa fa-pie-chart"></i> <span><?php echo _QXZ("Reports");?></span> </a>
           </li>
           <?php
			}

		else
			{
			if (($SSqc_features_active=='1') && ($qc_auth=='1')) 
				{ ?>
            <li class="treeview">
             <ul class="treeview-menu">
              <li <?php echo $qc_hh ?>><a href="<?php echo $ADMIN ?>?ADD=100000000000000"><i class="fa fa-circle-o"></i> Quality Control</a></li>
              <?php
			if (strlen($qc_hh) > 1) 
					{
				?>
               <li><a href="<?php echo $ADMIN ?>?ADD=100000000000000"><i class="fa fa-circle-o"></i>Show QC Campaigns</a></li>
               <li><a href="<?php echo $ADMIN ?>?ADD=100000000000000"><i class="fa fa-circle-o"></i>Enter QC Queue</a></li>
               <li><a href="<?php echo $ADMIN ?>?ADD=341111111111111"><i class="fa fa-circle-o"></i>Modify QC Codes</a></li>
               <?php }
				}
			}
		}
	?>
             </ul>
            </li>
    </ul>
   </section>
   <!-- /.sidebar -->
  </aside>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper mgg"> 
   <!-- Content Header (Page header) -->
   <section class="content-header">
    <h1>
            </h1>
    <!--<ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
          </ol>-->
   </section>
   <!-- Main content -->
   
   <!--Start of Tawk.to Script-->
<!--Start of Tawk.to Script-->
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/663c831a07f59932ab3d8f2a/1hte608nl';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
<!--End of Tawk.to Script-->
   <section class="content">
    <!-- Small boxes (Stat box) -->
    <!-- start for white portion  

<div class="row">
           
<div class="col-md-12">
              <div class="box">-->